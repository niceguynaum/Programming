#pragma once
class Bank
{
public:
	std::vector<User *> Users;
	
	Bank();
	~Bank();
};

